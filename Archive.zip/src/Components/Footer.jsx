/* eslint-disable no-unused-vars */
import React from "react";

const Footer = () => {
  return (
    <div>
      <footer className="py-5 bg-dark">
        <div className="container">
          <p className="m-0 text-center text-white">
            Copyright © Your Website 2023
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Footer;
